#!/bin/bash 



file="/home/qm/Desktop/Prog-bash/EX3/$1"

if [[ -e $file ]]; then
    echo "Le fichier $1 existe"
else 
    echo "Le fichier $1 n'existe pas"
fi
