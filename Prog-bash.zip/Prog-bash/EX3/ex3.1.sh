
#!/bin/bash

# Vérifier le nombre de paramètres
# -lt = inferieur à ce nombre
if [ $# -lt 1 ]; then
  echo "Synopsis: $0 [UID1] [UID2] ..."
  exit 1
fi

# Parcourir les paramètres
for uid in "$@"; do
  if [ "$uid" -ge 1000 ]; then
    echo "L'UID $uid est valide pour un utilisateur régulier."
  else
    echo "L'UID $uid n'est pas valide pour un utilisateur régulier."
  fi
done
