#!/bin/bash

# Script pour trouver le prochain UID disponible basé sur le fichier passwd
# Usage: ./next_uid.sh

# Chemin vers le fichier passwd
if [[ $# -lt 1 || $# -gt 2 ]]; then
    echo "Synopsis: $0 [fichier_passwd] [valeur_min]"     
    exit 1
fi

# Vérification fichier passwd
if [[ $# -eq 1 ]]; then
    passwd_file="/home/qm/Desktop/Prog-bash/EX3/$1"
    echo "$passwd_file"
else 
    passwd_file="/home/qm/Desktop/Prog-bash/EX3/passwd"
    echo "$passwd_file"
fi


if [[ $# -eq 2 ]]; then
    min_value=$2
    if [[ $min_value -lt 0 ]]; then
        echo "la valeur $min_value doit être supérieur ou égal à 0"
        exit 1
    fi
fi

# Définition des bornes pour la boucle
start=$min_value  # UID minimum possible
end=5000    # UID maximum possible

# Parcours des UID possibles pour trouver le prochain UID disponible
for uid in $(seq "$start" "$end"); do
  # Vérification si l'UID existe déjà dans le fichier passwd
  if ! grep -qE "^[^:]+:[^:]+:$uid:" "$passwd_file"; then
    echo "Le prochain UID disponible est : $uid"
    exit 0
  fi
done

echo "Impossible de trouver un UID disponible dans la plage spécifiée."
exit 1
