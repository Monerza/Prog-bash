#!/bin/bash

# Fonction d'affichage de l'aide
display_help() {
  echo "Synopsis: $0 [options]"
  echo "Options:"
  echo "  -f <passwd_file>     Spécifie le fichier passwd (par défaut : ./passwd)"
  echo "  -m <min_id>          Spécifie la valeur minimale de l'UID (par défaut : 0)"
  echo "  -M <max_id>          Spécifie la valeur maximale de l'UID (par défaut : 65535)"
  echo "  -u                   Affiche uniquement des UID pour utilisateurs normaux (équivalent à -m 1000)"
  echo "  -h                   Affiche l'aide"
  echo "  -n <nb_id>           Affiche les <nb_id> premiers UID disponibles"
  echo "  -c                   Les UID affichés sont consécutifs (avec -n)"
  echo "Note: Seules les options précédemment renseignées sont acceptées."
  echo "Statuts de sortie:"
  echo "  0 : Succès"
  echo "  1 : Erreur de paramètres ou d'options"
  echo "  2 : Erreur de fichier"
  echo "  3 : Aucun UID disponible"
}

# Fonction pour trouver le prochain UID disponible
find_next_uid() {
  local start="$1"
  local end="$2"
  local passwd_file="$3"

  for ((uid=start; uid<=end; uid++)); do
    if ! grep -qE "^.*:x:$uid:" "$passwd_file"; then
      echo "$uid"
      return 0
    fi
  done

  return 1
}

# Variables par défaut
passwd_file="/home/qm/Desktop/Prog-bash/EX4/passwd"
min_id=0
max_id=65535

# Analyse des options en utilisant getopts
while getopts ":f:m:M:uhn:c" opt; do
  case $opt in
    f)
      passwd_file="$OPTARG"
      ;;
    m)
      min_id="$OPTARG"
      ;;
    M)
      max_id="$OPTARG"
      ;;
    u)
      min_id=1000
      ;;
    h)
      display_help
      exit 0
      ;;
    n)
      nb_id="$OPTARG"
      ;;
    c)
      consecutive_ids=true
      ;;
    \?)
      echo "Erreur: Option invalide -$OPTARG"
      display_help
      exit 1
      ;;
    :)
      echo "Erreur: L'option -$OPTARG requiert un argument."
      display_help
      exit 1
      ;;
  esac
done

# Vérifier l'existence et les permissions du fichier passwd
if [ ! -f "$passwd_file" ] || [ ! -r "$passwd_file" ]; then
    echo "Erreur: Le fichier '$passwd_file' n'existe pas ou n'est pas accessible en lecture."
    exit 2
fi

# Appeler la fonction pour trouver le prochain UID disponible
next_uid=$(find_next_uid "$min_id" "$max_id" "$passwd_file")

if [ $? -eq 0 ]; then
    echo "Prochain UID disponible : $next_uid"
    exit 0
else
    echo "Erreur: Aucun UID disponible dans la plage spécifiée."
    exit 3
fi
