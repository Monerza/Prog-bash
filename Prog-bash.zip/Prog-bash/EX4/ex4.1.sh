#!/bin/bash

# Définition des valeurs par défaut
passwd_file=${1:-"/home/qm/Desktop/Prog-bash/EX4/passwd"}
help=false
min_uid=0
max_uid=65535

# Script pour trouver le prochain UID disponible basé sur le fichier passwd
# Usage: ./next_uid.sh
print_help() {
    echo "Synopsis: $0 [options]"
    echo "Options:"
    echo "  -f <passwd_file>      Spécifie le fichier passwd à utiliser (par défaut: ./passwd)"
    echo "  -m <min_id>           Spécifie la valeur minimale de l'UID (par défaut: 0)"
    echo "  -M <max_id>           Spécifie la valeur maximale de l'UID (par défaut: 65535)"
    echo "  -u                    Affiche uniquement des UID pour utilisateurs normaux (équivaut à -m 1000)"
    echo "  -h                    Affiche l'aide"
    echo "  -n <num_ids>          Affiche les <num_ids> premiers UID disponibles"
    echo "  -c                    Les UID affichés sont consécutifs (valide uniquement avec -n)"
    echo "Statuts de sortie:"
    echo "  0                     Succès"
    echo "  1                     Erreur"
}

display_next_uid() {
    local count=$1
    local uid=$min_uid
    local found=0

    while [ $count -gt 0 ]; do
        if [ $uid -gt $max_uid ]; then
            echo "Nombre d'UID insuffisant dans la plage spécifiée."
            exit 4
        fi

        if [ $user_only = true ] && [ $uid -lt 1000 ]; then
            uid=1000
        fi

        if grep -q "^.*:x:$uid:" $passwd_file; then
            uid=$((uid+1))
        else
            if [ $consecutive = true ]; then
                found=$((found+1))
                if [ $found -eq $count ]; then
                    echo "UID disponibles: $((uid-found+1))-$uid"
                    exit 0
                fi
            else
                echo "Prochain UID disponible: $uid"
                count=$((count-1))
                uid=$((uid+1))
            fi
        fi
    done
}

# Chemin vers le fichier passwd
if [[ $# -lt 1 || $# -gt 2 ]]; then
    echo "Synopsis: $0 [fichier_passwd] [valeur_min]"     
    exit 1
fi

# Vérification fichier passwd
if [[ $# -ge 1 && -f "$1" ]]; then
    passwd_file="/home/qm/Desktop/Prog-bash/EX4/$1"
    echo "$passwd_file"
else 
    echo "$passwd_file (fichier par défaut)"
fi

# Vérification de l'existence et des accès au fichier passwd
# L'opérateur logique || effectue une opération de OU logique entre les deux conditions. Cela signifie que si l'une des conditions est vraie
# Dans le contexte de l'expression [ ! -f $passwd_file ], le "!" est placé devant la condition -f $passwd_file. Cela signifie que la condition sera évaluée comme vraie si le fichier spécifié par $passwd_file n'existe pas.
if [ ! -f $passwd_file ] || [ ! -r $passwd_file ]; then
    echo "Le fichier passwd spécifié n'existe pas ou n'est pas accessible."
    exit 2
fi

# Définition de la valeur minimale d'UID
if [[ $# -eq 2 ]]; then
    min_value=$2
    if [[ $min_value -lt 0 ]]; then
        echo "la valeur $min_value doit être supérieur ou égal à 0"
        exit 1
    fi
fi

# Définition des bornes pour la boucle
start=$min_value  # UID minimum possible
end=5000    # UID maximum possible

# Parcours des UID possibles pour trouver le prochain UID disponible
display_next_uid () {
    for uid in $(seq "$start" "$end"); do
  # Vérification si l'UID existe déjà dans le fichier passwd
        if ! grep -qE "^[^:]+:[^:]+:$uid:" "$passwd_file"; then
            echo "Le prochain UID disponible est : $uid"
            exit 0
        fi
    done

    echo "Impossible de trouver un UID disponible dans la plage spécifiée."
    exit 1
}

while getopts ":f:m:M:uhn:c" opt; do
    case $opt in
        f)
            passwd_file=$OPTARG
            ;;
        m)

            ;;
        M)

            ;;
        u)

            ;;
        h)
            help=true
            ;;
        n)

            ;;
        c)

            ;;
        \?)

            ;;
        :)

            ;;
    esac
    
done

if $help; then
    print_help
    exit 0
fi
#Lancement script prochain UID disponible 
display_next_uid 
