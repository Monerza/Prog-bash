#!/bin/bash

log_error() {
    local error_message="$1"
    if [[ -z "$logfile" ]]; then
        echo "$error_message" >&2
    else
        echo "$error_message" >> "$logfile"  
    fi
}

test_and_mark() {
    file_path=$1
    backup_dir=$2

    # Vérifie si le fichier existe
    if [[ ! -f "$file_path" ]]; then
        echo "Erreur : Le # Fonction de log des erreurs fichier $file_path n'existe pas." >&2
        return 1
    fi

    # Vérifie si le fichier a l'extension correspondant au motif
    # basename va extraire le nom du fichier $file_path
    # awk -F va traiter la sortie de basename
    # -F définit le délimiteur est (.)
    # {if (NF>1) : script awk qui va permettre de trouver un point,donc après le point = est une extension
    file_extension=$(basename "$file_path" | awk -F. '{if (NF>1) {print $NF}}')
    if [[ -z $file_extension && -n $file_pattern ]]; then
        echo "Erreur : Pas d'extension trouvé pour le fichier : $file_path" >&2
        return 2
    fi
    # true si caract est non nul, si réussit &&
    if [[ -n $file_pattern && $file_extension != $file_pattern ]]; then
        echo "Erreur : L'extension du fichier $file_path ne correspond pas au motif $file_pattern." >&2
        return 2
    fi

  # Copie du fichier dans le répertoire backup
  cp "$file_path" "$backup_dir"
  return 0
}

while getopts "cL:b:" opt; do
    case "$opt" in
        c )
            count_files=true
            ;;
        L )
            log_file="$OPTARG"
            ;;
        b )
            backup_dir="$OPTARG"
            ;;
        * )
            echo "Erreur : Option invalide." >&2
            exit 1
            ;;
    esac
done

shift $((OPTIND - 1))

# accepte deux arguements
if [ $# -ne 2 ]; then
    echo "Erreur : Deux arguments sont requis." >&2
    exit 1
fi

parse_dir="$1"
file_pattern="$2"

# Vérifie si le répertoire parse_dir existe -d = répertoire
if [ ! -d "$parse_dir" ]; then
    echo "Erreur : Le répertoire $parse_dir n'existe pas." >&2
    exit 1
fi

# Vérifie si le répertoire backup existe, sinon le créer
if [ -z "$backup_dir" ]; then
    backup_dir="$parse_dir/backup"
else
    backup_dir="$parse_dir/$backup_dir"
fi

# Création du répertoir si arguement -b
mkdir -p "$backup_dir"

# Parcours des fichiers du répertoire parse_dir
nb_files=0

#Boucle for qui va regarde tous les fichiers dans le dossier $parse_dir
for i in "$parse_dir"/*; do
    # -f vrai si le fichier existe est un fichier régulier 
    if [ -f "$i" ]; then
        if test_and_mark "$i" "$backup_dir"; then
            nb_files=$((nb_files + 1))
        fi
    fi
done

# Nombre de fichiers copiés avec l'option -c
if [ "$count_files" = true ]; then
    echo "Nombre de fichiers copiés : $nb_files"
fi

exit 1

