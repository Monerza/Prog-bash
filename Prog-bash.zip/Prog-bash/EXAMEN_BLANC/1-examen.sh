#!/bin/bash

print_help() {
    echo "Usage: log_analyzer.sh [-h] [-o <out_file>] <log_list_path> <pattern> [patterns...]"
    echo "  -h              Display this help message."
    echo "  -o <out_file>   Save occurrences to <out_file> instead of displaying them on standard output."
    echo "  <log_list_path> Path to a file containing the logs to monitor."
    echo "  <pattern>       Pattern(s) to search for in the log files."
}

search_patterns() {
    local log_file=$1
    local patterns=("${@:2}")

    local found=false
    local line_number=0

    while IFS= read -r line; do
        ((line_number++))
        for pattern in "${patterns[@]}"; do
            if [[ $line =~ $pattern ]]; then
                if [[ $found == false ]]; then
                    echo "$line_number $log_file:"
                    found=true
                fi
                echo "$line"
            fi
        done
    done < "$log_file"

    if [[ $found == false ]]; then
        echo "$log_file: No occurrence found" 
    fi
}

out_file=""
log_list=""
patterns=()

while getopts ":ho:" opt; do
    case $opt in
        h)
            print_help
            exit 0
            ;;
        o)
            out_file=$OPTARG
            ;;
        \?)
            echo "Invalid option: -$OPTARG" >&2
            print_help >&2
            exit 1
            ;;
    esac
done

shift $((OPTIND - 1))

if [[ $# -lt 2 ]]; then
    echo "Error: At least two positional arguments are required." >&2
    print_help >&2
    exit 1
fi

log_list=$1
patterns=("${@:2}")

while IFS= read -r log_file; do
    search_patterns "$log_file" "${patterns[@]}"
done < "$log_list" >> "$out_file"

if [[ -z $out_file ]]; then
    exit 0
else
    if [[ -s $out_file ]]; then
        exit 0
    else
        echo "No occurrence found" >&2
        exit 1
    fi
fi

