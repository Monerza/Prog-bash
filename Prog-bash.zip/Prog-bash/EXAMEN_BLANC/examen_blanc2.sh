#!/bin/bash

# Fonction pour afficher l'aide
print_help() {
  echo "Usage: examen_blanc.sh <log_list_path> <pattern> [pattern2 pattern3 ...]"
  echo "Options:"
  echo "  -h                  Affiche l'aide"
  echo "  -o <out_file>       Enregistre les occurrences dans le fichier out_file"
}

# Fonction pour rechercher les occurrences dans un fichier de log
search_occurrences() {

    local log_file="$1"
    local pattern="$2"
    local line_number=0

    while IFS= read -r line; do
        ((line_number++))
        if [[ $line == *"$pattern"* ]]; then
            echo "$line_number $log_file:"
            echo "$line"
        fi
    done < "$log_file"
}

# Vérification des arguments
if [[ $# -lt 2 ]]; then
  echo "Nombre insuffisant d'arguments."
  print_help
  exit 1
fi

# Variables
log_list_path=""
patterns=()
out_file=""
show_help=false

# Traitement des options
while getopts ":ho:" opt; do
  case $opt in
    h)
      show_help=true
      ;;
    o)
      out_file="$OPTARG"
      ;;
    \?)
      echo "Option invalide: -$OPTARG" >&2
      exit 1
      ;;
  esac
done

# Affichage de l'aide si demandé
if [ "$show_help" = true ]; then
  print_help
  exit 0
fi

# Récupération des arguments positionnels
shift $((OPTIND - 1))
log_list_path="$1"
shift

# Vérification de l'existence du fichier log_list_path
if [ ! -f "$log_list_path" ]; then
  echo "Fichier log_list_path introuvable."
  exit 1
fi

# Lecture du fichier log_list_path et recherche des occurrences
while IFS= read -r log_file; do
    for pattern in "${patterns[@]}"; do
        if grep -q "$pattern" "$log_file"; then
            if [ -z "$out_file" ]; then
                search_occurrences "$log_file" "$pattern"
            else
                search_occurrences "$log_file" "$pattern" >> "$out_file"
            fi
        else
            echo "$log_file: No occurence found" >&2
        fi
    done
done < "$log_list_path"

