#!/bin/bash

# Fonction affichant l'aide
function display_help() {
    echo "Usage: $0 <log_list_path> <pattern> [pattern2] [pattern3] ..."
    echo "Options:"
    echo "  -h              Affiche l'aide"
    echo "  -o <out_file>   Enregistre les occurrences dans le fichier out_file"
}

# Fonction de recherche des occurrences dans un fichier de log
function search_occurrences() {
    local file="$1"
    local pattern="$2"
    local line_number=0
    local found=0

    while IFS= read -r line; do
        ((line_number++))
        if [[ $line =~ $pattern ]]; then
            echo "$line_number $file:"
            echo "$line"
            ((found++))
        fi
    done < "$file"

    if ((found == 0)); then
        echo "$file: No occurrence found" >&2
    fi
}

# Variables
log_list_path=""
patterns=()
out_file=""

# Traitement des options
while getopts "ho:" option; do
    case "$option" in
        h)
            display_help
            exit 0
            ;;
        o)
            out_file="$OPTARG"
            ;;
        ?)
            display_help >&2
            exit 1
            ;;
    esac
done

# Récupération des arguments positionnels
shift $((OPTIND - 1))
log_list_path="$1"
shift

# Vérification des arguments
if [[ -z $log_list_path || ! -f $log_list_path ]]; then
    echo "Erreur : le chemin vers le fichier log_list_path n'est pas valide ou n'existe pas." >&2
    exit 1
fi

if [[ $# -eq 0 ]]; then
    echo "Erreur : aucun pattern à rechercher n'a été spécifié." >&2
    exit 1
fi

# Lecture du fichier log_list_path
while IFS= read -r log_file; do
    for pattern in "${patterns[@]}"; do
        if [[ -n $out_file ]]; then
            search_occurrences "$log_file" "$pattern" >> "$out_file"
        else
            search_occurrences "$log_file" "$pattern"
        fi
    done
done < "$log_list_path"

