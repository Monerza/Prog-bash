
#!/bin/bash

# Fonction d'affichage de l'aide
print_help() {
    echo "Utilisation: backup_manager [-c file1[,file2[,file3[,...]]]] [-h] [-i index_file] [-L logfile] archive"
    echo "Options:"
    echo "  -c file1[,file2[,file3[,...]]] : Créer une nouvelle archive contenant les fichiers spécifiés"
    echo "  -h : Afficher l'aide"
    echo "  -i index_file : Spécifier le nom du fichier d'index de l'archive (par défaut : .index_list)"
    echo "  -L logfile : Ajouter les erreurs au fichier logfile plutôt que de les afficher sur la sortie standard"
    echo "archive : Chemin de l'archive à traiter"
}

# Fonction de vérification de compatibilité
check_compat() {
    archive_file="$1"
    file_path="$2"

    tar tf "$archive_file" | grep -qFx "$(basename "$file_path")"

    if [ $? -eq 0 ]; then
        return 1
    else
        return 0
    fi
}

# Fonction de création de l'archive avec les fichiers spécifiés
create_archive() {
    archive_file="$1"
    index_file="$2"
    files="$3"

    # Créer une archive vide si elle n'existe pas
    if [ ! -f "$archive_file" ]; then
        tar cf "$archive_file" --files-from /dev/null
    fi

    # Créer un index vide si le fichier n'existe pas
    if [ ! -f "$index_file" ]; then
        touch "$index_file"
    fi

    # Variables pour le suivi des erreurs
    error_flag=0
    processing_error=0

    # Parcourir chaque fichier spécifié
    IFS=',' read -ra file_list <<< "$files"
    for file_path in "${file_list[@]}"; do
        # Vérifier l'existence du fichier
        if [ -f "$file_path" ] && [ -r "$file_path" ]; then
            # Vérifier la compatibilité avec l'archive existante
            check_compat "$archive_file" "$file_path"
            compatibility_status=$?

            if [ $compatibility_status -eq 0 ]; then
                # Ajouter le fichier à l'archive
                tar rf "$archive_file" -C "$(dirname "$file_path")" "$(basename "$file_path")"

                # Ajouter le chemin absolu dans le fichier index
                echo "$file_path" >> "$index_file"
            else
                echo "Conflit détecté pour le fichier : $file_path" >&2
                error_flag=1
            fi
        else
            echo "Impossible de lire le fichier : $file_path" >&2
            error_flag=1
        fi

        # Vérifier si une erreur de traitement a été rencontrée
        if [ $? -ne 0 ]; then
            processing_error=1
            break
        fi
    done

    # Vérifier le statut de sortie
    if [ $processing_error -eq 1 ]; then
        return 2
    elif [ $error_flag -eq 1 ]; then
        return 1
    else
        return 0
    fi
}

# Fonction de déploiement des fichiers de l'archive
deploy_archive() {
    archive_file="$1"
    index_file="$2"

    # Extraire le fichier .index_list de l'archive
    tar xf "$archive_file" "$index_file"

    # Vérifier si l'extraction du fichier .index_list a réussi
    if [ $? -ne 0 ]; then
        echo "Erreur lors de l'extraction du fichier $index_file" >&2
        return 2
    fi

    # Parcourir chaque ligne du fichier .index_list
    while IFS= read -r destination_path; do
        # Extraire le fichier correspondant de l'archive
        tar xf "$archive_file" -C "$(dirname "$destination_path")" "$(basename "$destination_path")"

        # Vérifier si l'extraction du fichier a réussi
        if [ $? -ne 0 ]; then
            echo "Erreur lors de l'extraction du fichier : $destination_path" >&2
            return 1
        fi
    done < "$index_file"

    # Supprimer le fichier .index_list
    rm -f "$index_file"

    # Retourner le statut de sortie approprié
    return 0
}

# Script principal

# Variables par défaut
index_file=".index_list"
log_file=""
action="deploy"

# Analyser les options de ligne de commande
while getopts "c:hi:L:" option; do
    case $option in
        c)
            action="create"
            files="$OPTARG"
            ;;
        h)
            print_help
            exit 0
            ;;
        i)
            index_file="$OPTARG"
            ;;
        L)
            log_file="$OPTARG"
            ;;
        *)
            print_help >&2
            exit 1
            ;;
    esac
done

# Déplacer les arguments pour sauter les options analysées
shift $((OPTIND - 1))

# Vérifier si un argument (archive) est fourni
if [ $# -ne 1 ]; then
    print_help >&2
    exit 1
fi

archive_file="$1"

# Rediriger les erreurs vers le fichier de log si spécifié
if [ -n "$log_file" ]; then
    exec 2>> "$log_file"
fi

# Effectuer l'action appropriée en fonction des options fournies
if [ "$action" = "create" ]; then
    create_archive "$archive_file" "$index_file" "$files"
    exit_status=$?
else
    deploy_archive "$archive_file" "$index_file"
    exit_status=$?
fi

# Afficher un message de réussite ou d'échec selon le statut de sortie
if [ $exit_status -eq 0 ]; then
    echo "Traitement terminé avec succès."
else
    echo "Traitement terminé avec des erreurs."
fi

exit $exit_status

