
#!/bin/bash

# Fonction pour afficher l'utilisation du script
usage() {
    echo "Usage: $0 [-u user]"
    exit 1
}

# Fonction pour afficher les informations d'un utilisateur
display_user_info() {
    local username=$1
    local uid=$2
    local shell=$3

    echo "Utilisateur: $username"
    echo "UID: $uid"
    echo "Shell par défaut: $shell"
}

# Vérification des options en utilisant getopts
while getopts "u:" opt; do
    case $opt in
        u)
            # Récupération de l'utilisateur spécifié
            user=$OPTARG

            # Vérification si l'utilisateur existe
            if ! grep -q "^$user:" /home/qm/Desktop/Prog-bash/EX5/passwd; then
                echo "Erreur: L'utilisateur '$user' n'existe pas."
                exit 2
            fi

            # Récupération des informations de l'utilisateur
            uid=$(grep "^$user:" /home/qm/Desktop/Prog-bash/EX5/passwd | awk -F: '{print $3}')
            shell=$(grep "^$user:" /home/qm/Desktop/Prog-bash/EX5/passwd | awk -F: '{print $7}')

            # Vérification de l'UID de l'utilisateur
            if [[ $uid -lt 1000 ]]; then
                echo "Erreur: L'utilisateur '$user' n'est pas un utilisateur normal."
                exit 3
            fi

            # Affichage des informations de l'utilisateur
            display_user_info "$user" "$uid" "$shell"
            exit 0
            ;;
        *)
            usage
            ;;
    esac
done

# Affichage des informations de tous les utilisateurs normaux
awk -F: '$3 >= 1000 {print $1, $3, $7}' /home/qm/Desktop/Prog-bash/EX5/passwd | while read -r username uid shell; do
    display_user_info "$username" "$uid" "$shell"
    echo "----------"
done

