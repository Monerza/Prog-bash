#!/bin/bash

# Fonction pour afficher l'utilisation du script
usage() {
    echo "Utilisation: $0 [-u utilisateur]"
    exit 1
}

# Vérifier les options de ligne de commande
while getopts ":u:" opt; do
    case $opt in
        u)
            utilisateur=$OPTARG
            ;;
        \?)
            echo "Option invalide: -$OPTARG" >&2
            usage
            ;;
        :)
            echo "L'option -$OPTARG nécessite un argument." >&2
            usage
            ;;
    esac
done

# Vérifier si l'option -u est spécifiée
if [[ -n $utilisateur ]]; then
    # Vérifier si l'utilisateur existe et si son UID est supérieur à 1000 (ou 500)
    if id -u $utilisateur >/dev/null 2>&1 && [[ $(id -u $utilisateur) -ge 1000 ]]; then
        # Afficher le shell par défaut de l'utilisateur
        echo "Shell par défaut de $utilisateur: $(getent passwd $utilisateur | awk -F: '{print $NF}')"
    else
        echo "L'utilisateur $utilisateur n'existe pas ou n'est pas un utilisateur normal."
        exit 2
    fi
else
    # Liste des comptes utilisateurs normaux
    comptes=$(awk -F: '$3 >= 1000 {print $1}' /home/qm/Desktop/Prog-bash/EX5/passwd)

    if [[ -z $comptes ]]; then
        echo "Aucun compte utilisateur normal trouvé."
        exit 3
    fi

    # Afficher les comptes utilisateurs normaux et leurs shells par défaut
    echo "Comptes utilisateurs normaux du système:"
    for compte in $comptes; do      
        shell=$(getent passwd $utilisateur | awk -F: '{print $7}')
        if [[ -z "$shell" ]]; then
            shell=$(getent passwd $utilisateur | awk -F: '{print $6}')
        fi
        echo "Utilisateur: $compte  Shell: $shell"
    done
fi

