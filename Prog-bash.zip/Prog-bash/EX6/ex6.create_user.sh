#!/bin/bash

usage() {
    echo "Utilisation : $0 [options] fichier"
    echo "-h Affiche l'aide"
    echo "-s SEP Spécifie un séparateur personnalisé (défaut: )"
}

create_user() {
    login=$1
    password=$2
    echo "Création de l'utilisateur : $login"
    #sudo useradd -m -p $(openssl passwd -1 $2) $1
    echo "Login = $login"
    echo "Password = $password"
}

if [[ $# -eq 0 ]]; then
    echo "Erreur : Aucun fichier spécifié."
    usage
    exit 1
fi

while getopts "hs:" opt; do
    case $opt in
        h )
            usage
            exit 0
            ;;
        s )
            # Traitement du paramètre b 
            separator="$OPTARG"
            ;;
        \? )
            echo "Erreur : paramètre non reconnu : -$OPTARG"
            usage
            exit 1
            ;;
    esac
done

shift $((OPTIND - 1))

file=$1
while IFS=$separator read -r login password; do
    create_user "$login" "$password"
done < "$file"
