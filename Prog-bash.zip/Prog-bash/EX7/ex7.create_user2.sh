
#!/bin/bash

# Définition des options par défaut
separator=";"
logfile=""
error_logfile=""

# Fonction d'affichage de l'aide
display_help() {
  echo "Utilisation : $0 [-h] [-s SEPARATOR] [-l LOGFILE] [-L ERROR_LOGFILE] fichier"
  echo "Crée des comptes utilisateurs à partir d'un fichier comprenant login et mot de passe, séparés par des points virgules."
  echo ""
  echo "Options :"
  echo "-h                Affiche l'aide"
  echo "-s SEPARATOR      Définit le séparateur (par défaut : ;)"
  echo "-l LOGFILE        Définit le fichier de log"
  echo "-L ERROR_LOGFILE  Définit le fichier de log des erreurs"
  echo ""
  echo "L'ordre dans le fichier doit être login;mot_de_passe"
}

# Fonction de création d'un compte utilisateur
create_user() {
  local login="$1"
  local password="$2"
  
  # Vérifier si le compte utilisateur existe déjà
  if id "$login" >/dev/null 2>&1; then
    echo "Le compte utilisateur $login existe déjà. Ignoré."
    return
  fi
  
  # Création du compte utilisateur
  echo "Création du compte utilisateur $login"
  # Ajouter ici la commande de création du compte utilisateur
  
  if [ $? -eq 0 ]; then
    echo "Compte utilisateur $login créé avec succès."
  else
    echo "Erreur lors de la création du compte utilisateur $login."
    echo "$(date +'%Y-%m-%d %H:%M:%S') : Erreur lors de la création du compte utilisateur $login" >> "$error_logfile"
  fi
}

# Analyse des options de ligne de commande
while getopts "hs:l:L:" opt; do
  case $opt in
    h) 
        display_help
        exit
        ;;
    s) 
        separator="$OPTARG"
        ;;
    l) 
        logfile="$OPTARG"
        ;;
    L) 
        error_logfile="$OPTARG"
        ;;
    *) 
        echo "Option invalide : -$OPTARG"
        exit 1
        ;;
  esac
done

shift $((OPTIND - 1))

# Vérifier si un fichier est fourni en argument
if [ $# -eq 0 ]; then
  echo "Fichier non spécifié. Utilisez l'option -h pour afficher l'aide."
  exit 1
fi

filename="$1"

# Vérifier si le fichier existe
if [ ! -f "$filename" ]; then
  echo "Le fichier $filename n'existe pas."
  exit 1
fi

# Vérifier si le fichier de log existe et le créer s'il n'existe pas
if [ -n "$logfile" ] && [ ! -f "$logfile" ]; then
  touch "$logfile"
fi

# Vérifier si le fichier de log des erreurs existe et le créer s'il n'existe pas
if [ -n "$error_logfile" ] && [ ! -f "$error_logfile" ]; then
  touch "$error_logfile"
fi

# Lire le fichier ligne par ligne
while IFS="$separator" read -r login password; do
  create_user "$login" "$password"
  
  # Ajouter les informations de création du compte utilisateur au fichier de log
  if [ -n "$logfile" ]; then
    echo "$(date +'%Y-%m-%d %H:%M:%S') : Création du compte utilisateur $login" >> "$logfile"
  fi
done < "$filename"

