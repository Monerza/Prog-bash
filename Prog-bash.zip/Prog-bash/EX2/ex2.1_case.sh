#!/bin/bash

for i in $@; do
    case $i in
        "robert")
            echo "Bonjour Robert";;
        "test")
            echo "Ceci est un compte test";;
        "root")
            echo "Bienvenue cher administateur";;
        *)
            echo "Aucun paramètre";;
    esac
done

