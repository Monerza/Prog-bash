#!/bin/bash

count=0
declare -A params

echo "Nombre de paramètres: $#"

while (( "$#" )); do
    param=$1
    case $param in
        "robert")
            ((params["robert"]++))
            ;;
        "test")
            ((params["test"]++))
            ;;
        "root")
            ((params["root"]++))
            ;;
        *)
            echo "Ce paramètre est inconnu"
            exit 1
            ;;
    esac
    shift
done

for key in "${!params[@]}"; do
    echo "$key : ${params[$key]}"
done


# "${!params[@]}" est une expansion spécifique en bash qui renvoie toutes les clés du tableau associatif params.

# Le symbole ! devant params indique que nous voulons accéder aux clés plutôt qu'aux valeurs du tableau associatif.


# [@] est une syntaxe qui spécifie que nous voulons accéder à tous les éléments du tableau associatif plutôt qu'à un élément spécifique.
