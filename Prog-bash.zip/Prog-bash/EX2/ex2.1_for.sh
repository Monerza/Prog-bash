#!/bin/bash

nb_param=$#

for i in $@; do
    if [ $i = "robert" ]; then
        echo "Bonjour robert"
    elif [ $i = "test" ]; then
        echo "Ceci est un compte test"
    elif [ $i = "root" ]; then
        echo "Bienvenue cher administateur"
    elif [ $# -eq 0 ]; then
        echo "Aucun paramètre"
    else
        echo "Paramètre inconnu"
    fi  
done


