#!/bin/bash

interne=Programmation
publique=bash
id=
echo "$interne"
echo "$publique"

if [ -z $id ]; then
    echo "Variable vide">&2
else
    echo "La variable est $interne"
fi
