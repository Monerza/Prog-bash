#!/bin/bash

a=1
b=2

if [ "$a" -eq "$b" ]; then
    echo "a et b = $a$b"
else 
    echo "Les variables sont différentes"
fi
