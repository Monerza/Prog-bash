a=$1

if [ $a = "quentin" ]; then
    echo "Je m'appelle quetin"
    exit 1
elif [ $a = "arnaud" ]; then
    echo "Je m'appelle arnaud"
    exit 1
else
    echo "Para inconnu"
fi
